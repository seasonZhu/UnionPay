<h4>常见php问题：</h4>
<p class="faq">
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=194&level=0&from=0" target="_blank">Call to undefined function openssl_pkcs12_read()</a>
</p>
<p class="faq">
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=182&level=0&from=0" target="_blank">windows版的php如何开启openssl</a>
</p>
<p class="faq">
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=190&level=0&from=0" target="_blank">supplied parameter cannot be coerced into an X509 certificate</a>
</p>
<p class="faq">
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=183&level=0&from=0" target="_blank">没有找到证书ID为[3474813271258769001041842579301293446]的证书</a>
</p>

<hr />
<?php include $_SERVER ['DOCUMENT_ROOT'] . '/upacp_demo_app/pages/more_faq.php';?>

