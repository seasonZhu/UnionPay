测试卡号：与银联测试环境联调使用的卡号 <a href="https://open.unionpay.com/ajweb/help/faq/list?id=4&level=0&from=0" target="_blank">测试卡号</a><br><br>
<a href="pages/api_05_app/special_use_purchase.php" target="_blank">报文特殊用法</a><br>
<br>
常见咨询：<br>
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=9&level=0&from=0" target="_blank">消费撤销和退货有什么区别？</a><br>
<a href="https://open.unionpay.com/ajweb/help/faq/list?id=120&level=0&from=0" target="_blank">退款类交易的手续费如何收取？</a><br>
<br>
【重要提醒】<br>
请注意退货和消费撤销是异步接口，同步应答respCode=00仅代表受理成功，需用查询接口的origRespCode和通知接口的respCode判断。<br>
<br>