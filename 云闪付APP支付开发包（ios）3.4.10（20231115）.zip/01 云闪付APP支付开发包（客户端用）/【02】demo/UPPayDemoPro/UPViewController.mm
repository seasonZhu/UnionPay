//
//  UPViewController.m
//  UPPayDemo
//
//  Created by szwang on 16-03-30.
//  Copyright (c) 2016年 China UnionPay. All rights reserved.
//

#import "UPViewController.h"
#import "UPPaymentControl.h"


#define kVCTitle                @"商户测试"

#define kNote                   @"提示"
#define kConfirm                @"确定"
#define kErrorNet               @"网络错误"
#define kResult                 @"支付结果：%@"

#define KBtn_width              160
#define KBtn_height             40
#define KXOffSet                (self.view.frame.size.width - KBtn_width) / 2
#define KYOffSet                120
#define kWithNavigation         44
#define kCellHeight_Normal      50
#define kCellHeight_Manual      145





@interface UPViewController ()
{
    UIAlertView*                _alertView;
    NSMutableData*              _responseData;
    CGFloat                     _maxWidth;
    CGFloat                     _maxHeight;
    UITableView*                _tableView;


}

@property(nonatomic, copy)NSString *tnMode;

@property (nonnull,strong)UITextField *tnProductText;
@property (nonnull,strong)UITextField *tnPMText;
@property (nonnull,strong)UITextField *tnTestText;

- (void)extendedLayout;
- (void)showAlertMessage:(NSString*)msg;
- (void)hideAlert;

@end

@implementation UPViewController
@synthesize tnMode;

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = kVCTitle;
    [self extendedLayout];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _maxWidth, _maxHeight)];
    [self.view addSubview:_tableView];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
}

- (void) productVerify {
    self.tnMode = @"00";

    if(self.tnProductText.text.length >0) {
        [self.tnProductText resignFirstResponder];
        [[UPPaymentControl defaultControl] startPay:self.tnProductText.text fromScheme:@"UPPayDemo" mode:self.tnMode viewController:self];

    }
    else {
        [self showAlertMessage:@"tn不能为空"];
    }
}

- (void) pmVerify {
    self.tnMode = @"01";
    if(self.tnPMText.text.length >0) {
        [self.tnPMText resignFirstResponder];
        [[UPPaymentControl defaultControl] startPay:self.tnPMText.text fromScheme:@"UPPayDemo" mode:self.tnMode viewController:self];
    }
    else {
        [self showAlertMessage:@"tn不能为空"];
    }
}

- (void) testVerify {
    self.tnMode = @"02";
    if(self.tnTestText.text.length >0 ) {
        [self.tnPMText resignFirstResponder];
        [[UPPaymentControl defaultControl] startPay:self.tnTestText.text fromScheme:@"UPPayDemo" mode:self.tnMode viewController:self];
    }
    else {
        [self showAlertMessage:@"tn不能为空"];
    }
}



- (void)extendedLayout
{
    BOOL iOS7 = [UIDevice currentDevice].systemVersion.floatValue >= 7.0;
    if (iOS7) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    CGFloat offset = iOS7 ? 64 : 44;
    _maxWidth = CGRectGetWidth([UIScreen mainScreen].bounds);
    _maxHeight = CGRectGetHeight([UIScreen mainScreen].bounds)-offset;
    self.navigationController.navigationBar.translucent = NO;
}

#pragma UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = kCellHeight_Normal;
    if (indexPath.section==2) {
        height = kCellHeight_Manual;
    }
    return  height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.detailTextLabel.font = [UIFont systemFontOfSize:10];
    switch (indexPath.row) {
        case 0:
        {
            UIButton* btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [btnStartPay setTitle:@"生产验证[00]" forState:UIControlStateNormal];
            [btnStartPay addTarget:self action:@selector(productVerify) forControlEvents:UIControlEventTouchUpInside];
            [btnStartPay setFrame:CGRectMake(200, 10, 120, 40)];
            [cell.contentView addSubview:btnStartPay];
            
            self.tnProductText = [[UITextField alloc] initWithFrame:CGRectMake(20,10,180,40)];
            self.tnProductText.placeholder = @"请输入正式环境tn";
            self.tnProductText.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
            self.tnProductText.clearButtonMode = UITextFieldViewModeWhileEditing;
            [self.tnProductText becomeFirstResponder];
            [cell.contentView addSubview:self.tnProductText];
            
            cell.accessoryType = UITableViewCellAccessoryNone;

        }
            
            break;
            
        case 1:
        {
            UIButton* btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [btnStartPay setTitle:@"PM验证[01]" forState:UIControlStateNormal];
            [btnStartPay addTarget:self action:@selector(pmVerify) forControlEvents:UIControlEventTouchUpInside];
            [btnStartPay setFrame:CGRectMake(200, 10, 120, 40)];
            [cell.contentView addSubview:btnStartPay];
            
            self.tnPMText = [[UITextField alloc] initWithFrame:CGRectMake(20,10,180,40)];
            self.tnPMText.placeholder = @"请输入PM环境tn";
            self.tnPMText.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
            self.tnPMText.clearButtonMode = UITextFieldViewModeWhileEditing;
            [cell.contentView addSubview:self.tnPMText];
            
            cell.accessoryType = UITableViewCellAccessoryNone;

        }
            
            break;
            
        case 2:
        {
            UIButton* btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            btnStartPay = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [btnStartPay setTitle:@"内部测试[02]" forState:UIControlStateNormal];
            [btnStartPay addTarget:self action:@selector(testVerify) forControlEvents:UIControlEventTouchUpInside];
            [btnStartPay setFrame:CGRectMake(200, 10, 120, 40)];
            [cell.contentView addSubview:btnStartPay];
            
            self.tnTestText = [[UITextField alloc] initWithFrame:CGRectMake(20,10,180,40)];
            self.tnTestText.placeholder = @"请输入内部测试tn";
            self.tnTestText.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
            self.tnTestText.clearButtonMode = UITextFieldViewModeWhileEditing;
            [cell.contentView addSubview:self.tnTestText];
            
            cell.accessoryType = UITableViewCellAccessoryNone;

        }
            
            break;
            
            
        default:
            break;
    }
    
    
    
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
             [tableView deselectRowAtIndexPath:indexPath animated:YES];
            return;
            break;
            
        case 1:
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            break;
            
        case 2:
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            break;
            
            
        default:
            break;
    }
    
    
}



#pragma mark - Alert


- (void)showAlertMessage:(NSString*)msg
{
    [self hideAlert];
    _alertView = [[UIAlertView alloc] initWithTitle:kNote message:msg delegate:self cancelButtonTitle:kConfirm otherButtonTitles:nil, nil];
    [_alertView show];
}

- (void)hideAlert
{
    if (_alertView != nil)
    {
        [_alertView dismissWithClickedButtonIndex:0 animated:NO];
        _alertView = nil;
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    _alertView = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
