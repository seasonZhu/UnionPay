//
//  UPViewController.m
//  UPPayDemo
//
//  Created by szwang on 16-03-30.
//  Copyright (c) 2016年 China UnionPay. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UPViewController;

@interface UPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *viewController;

@end
