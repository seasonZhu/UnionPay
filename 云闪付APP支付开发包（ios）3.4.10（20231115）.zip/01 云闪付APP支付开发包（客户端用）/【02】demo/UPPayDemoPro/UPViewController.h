//
//  UPViewController.m
//  UPPayDemo
//
//  Created by szwang on 16-03-30.
//  Copyright (c) 2016年 China UnionPay. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UPViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UITextFieldDelegate>

@end
